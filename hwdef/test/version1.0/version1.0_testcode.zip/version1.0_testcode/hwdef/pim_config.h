// SPDX-License-Identifier: MIT
//////////////////////////////////////////////////////////////////////////////////
// pim_config.h — the platform constants, as compile-time defaults.
//
// THIS FILE IS SOURCE, NOT OUTPUT.  It used to be generated into the tree on every
// build; now it carries a DEFAULT for every value and scripts/setup.sh overrides
// them with -D from the conf you selected.  platform/*.conf is still the single
// source of truth — this is only what the compiler sees when nobody said otherwise.
//
// THE DEFAULTS ARE CH4, and that is a deliberate choice rather than a neutral one:
// there is no such thing as a neutral channel count.  A build that reaches these
// values took no platform from anybody, and PIM_CONFIG_FROM_CONF stays 0 to say so
// — pim_platform_check() turns that into a refusal rather than a warning, because a
// wrong channel count cannot be told apart from success by anything downstream.
//
// WATCH THE STRIDE (platform/ch4.conf).  CH4 packs 64 banks into the same 32 GiB of
// direct aperture, so PIM_BANK_STRIDE HALVES to 512 MiB while PIM_BANK_WINDOW stays
// 256 MiB.  Window is not stride in ANY image, but ch4 is the one where the two
// numbers move independently, so nothing here may assume they track each other.
//
// TO CHANGE A DEFAULT: edit platform/ch4.conf, then `hwdef/gen_config.sh --header`
// with ch4 selected and paste the result here.  Do not hand-edit one value — the
// whole point is that these arrive as a SET.
//////////////////////////////////////////////////////////////////////////////////
#ifndef PIM_CONFIG_H
#define PIM_CONFIG_H

// 1 when scripts/setup.sh supplied every value below from a conf; 0 when this is a
// bare `make` that fell through to the defaults.  pim_platform_check() reads it.
#ifndef PIM_CONFIG_FROM_CONF
#define PIM_CONFIG_FROM_CONF 0
#endif

#ifndef PIM_PLATFORM_NAME
#define PIM_PLATFORM_NAME   "ch4"
#endif

// The symlink itself, NOT what it resolves to — pim_platform_check() readlink()s
// this, and readlink on a real file fails with EINVAL.  Empty by default because a
// developer's absolute path baked in as a fallback would make a moved or cloned
// tree read someone else's selection and claim agreement with it.
#ifndef PIM_CONF_PATH
#define PIM_CONF_PATH       ""
#endif

// ---- topology ----
#ifndef PIM_NCH
#define PIM_NCH             4u
#endif
#ifndef PIM_NBANK
#define PIM_NBANK           16u
#endif

// ---- control plane (BAR2) ----
#ifndef PIM_BAR2_AXI_BASE
#define PIM_BAR2_AXI_BASE   0x020200000000ULL
#endif
#ifndef PIM_OFF_GPR
#define PIM_OFF_GPR         0x000000ULL
#endif
#ifndef PIM_OFF_CFR
#define PIM_OFF_CFR         0x400000ULL
#endif
#ifndef PIM_OFF_VIOL
#define PIM_OFF_VIOL        0x401000ULL
#endif
#ifndef PIM_OFF_IMEM
#define PIM_OFF_IMEM        0x600000ULL
#endif

// ---- path A: direct HBM.  WINDOW IS NOT STRIDE ----
#ifndef PIM_HBM_BASE
#define PIM_HBM_BASE        0x004000000000ULL
#endif
#ifndef PIM_HBM_CH_SPAN
#define PIM_HBM_CH_SPAN     0x200000000ULL
#endif
#ifndef PIM_BANK_STRIDE
#define PIM_BANK_STRIDE     0x20000000ULL
#endif
#ifndef PIM_BANK_WINDOW
#define PIM_BANK_WINDOW     0x10000000ULL
#endif

// ---- path B: MC s_axi ----
#ifndef PIM_MC_BASE
#define PIM_MC_BASE         0x020400000000ULL
#endif
#ifndef PIM_MC_CH_SPAN
#define PIM_MC_CH_SPAN      0x100000000ULL
#endif

// ---- policy ----
#ifndef PIM_UPLOAD_PATH
#define PIM_UPLOAD_PATH     "direct"
#endif
#ifndef PIM_NTAIL_POLICY
#define PIM_NTAIL_POLICY    "pad"
#endif
#ifndef PIM_SCHEDULE
#define PIM_SCHEDULE        "group"
#endif
// NOT #ifndef-guarded with a bare -D: `-DPIM_FEATURE_T_LATCH` with no value makes
// the compiler define it as 1, which flips the gate ON silently.  gen_config.sh's
// req() refusing an empty conf value is what keeps that from happening.
#ifndef PIM_FEATURE_T_LATCH
#define PIM_FEATURE_T_LATCH 0
#endif

// The channel address map, as MODE_CTRL's bit: 0 ChRoBaCo, 1 RoChBaCo.  The default
// is the register's own reset state, so a board nobody configured and a binary
// nobody configured agree — which is the only agreement worth having by default.
#ifndef PIM_ADDR_MAP
#define PIM_ADDR_MAP        0
#endif

#endif // PIM_CONFIG_H
