# version1.0 test code

emulator_top 의 보드 검증 프로그램 소스와 문서. 캡처 데이터(.ila/.csv)는 들어있지 않다.

```
hwdef/                런타임 — 레지스터 맵, 플랫폼 상수, 주소 디코딩
hwdef/test/           검증 프로그램 8개  ← 여기 README 가 프로그램 설명
hwdef/test/version1.0/ 이번 파형 캡처 실험 방식
platform/             ch1/ch2/ch4 플랫폼 설정
scripts/setup.sh      빌드 진입점
```

## 빌드

`make` 를 직접 돌리지 말 것. pim_config.h 의 컴파일 기본값(ch4)이 들어가 보드와
주소 체계가 어긋난다. 채널 수는 비트스트림의 성질이라 platform/active 가 정한다.

```bash
./scripts/setup.sh            # platform/active 를 읽어 그 플랫폼으로 빌드
./scripts/setup.sh --status
```

원본 트리에서는 `emulator_top/` 아래 이 구조 그대로다.
